package com.cinemabook.booking;

import com.cinemabook.show.Show;
import com.cinemabook.show.ShowService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/bookings")
public class BookingController {

    private final BookingService bookingService;
    private final ShowService showService;

    public BookingController(BookingService bookingService, ShowService showService) {
        this.bookingService = bookingService;
        this.showService = showService;
    }

    // Customer: my bookings
    @GetMapping("/my")
    public String myBookings(HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        String userId = (String) session.getAttribute("userId");
        model.addAttribute("bookings", bookingService.getBookingsByUserId(userId));
        model.addAttribute("userRole", session.getAttribute("userRole"));
        model.addAttribute("userName", session.getAttribute("userName"));
        return "booking/list";
    }

    // Admin: all bookings
    @GetMapping
    public String allBookings(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";
        List<Booking> all = bookingService.getAllBookings();
        model.addAttribute("bookings", all);
        model.addAttribute("totalCount", all.size());
        model.addAttribute("confirmedCount", bookingService.countByStatus("CONFIRMED"));
        model.addAttribute("cancelledCount", bookingService.countByStatus("CANCELLED"));
        model.addAttribute("userRole", session.getAttribute("userRole"));
        model.addAttribute("userName", session.getAttribute("userName"));
        return "booking/list";
    }

    // Booking form — shows show info + seat picker
    @GetMapping("/new")
    public String bookingForm(@RequestParam String showId,
                               HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        Show show = showService.getShowById(showId).orElse(null);
        if (show == null || show.getAvailableSeats() == 0)
            return "redirect:/movies";
        model.addAttribute("show", show);
        model.addAttribute("userRole", session.getAttribute("userRole"));
        model.addAttribute("userName", session.getAttribute("userName"));
        return "booking/form";
    }

    // Create booking
    @PostMapping
    public String createBooking(@RequestParam String showId,
                                @RequestParam int seats,
                                HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        String userId = (String) session.getAttribute("userId");

        Show show = showService.getShowById(showId).orElse(null);
        if (show == null || show.getAvailableSeats() < seats)
            return "redirect:/movies";

        boolean reduced = showService.reduceSeats(showId, seats);
        if (!reduced) return "redirect:/bookings/new?showId=" + showId + "&error=seats";

        Booking booking = bookingService.saveBooking(
            userId, showId, show.getMovieTitle(),
            show.getDate(), show.getTime(), show.getHall(),
            seats, show.getPrice()
        );
        return "redirect:/payments/new?bookingId=" + booking.getBookingId()
                + "&amount=" + booking.getTotalAmount();
    }

    // View a booking detail
    @GetMapping("/{id}")
    public String detail(@PathVariable String id, HttpSession session, Model model) {
        if (!isLoggedIn(session)) return "redirect:/login";
        String userId = (String) session.getAttribute("userId");
        String role = (String) session.getAttribute("userRole");
        bookingService.getBookingById(id).ifPresent(b -> {
            if (b.getUserId().equals(userId) || "ADMIN".equals(role))
                model.addAttribute("booking", b);
        });
        model.addAttribute("userRole", role);
        return "booking/detail";
    }

    // Cancel booking
    @PostMapping("/{id}/cancel")
    public String cancel(@PathVariable String id, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        bookingService.getBookingById(id).ifPresent(b -> {
            bookingService.cancelBooking(id);
            showService.restoreSeats(b.getShowId(), b.getSeats());
        });
        if (isAdmin(session)) return "redirect:/bookings";
        return "redirect:/bookings/my";
    }

    // Admin: delete booking
    @PostMapping("/{id}/delete")
    public String delete(@PathVariable String id, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/login";
        bookingService.getBookingById(id).ifPresent(b -> {
            if ("CONFIRMED".equals(b.getStatus()))
                showService.restoreSeats(b.getShowId(), b.getSeats());
        });
        bookingService.deleteBooking(id);
        return "redirect:/bookings";
    }

    private boolean isLoggedIn(HttpSession session) {
        return session.getAttribute("userId") != null;
    }

    private boolean isAdmin(HttpSession session) {
        return "ADMIN".equals(session.getAttribute("userRole"));
    }
}
