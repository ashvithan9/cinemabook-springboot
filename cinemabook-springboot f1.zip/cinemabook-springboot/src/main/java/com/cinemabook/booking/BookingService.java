package com.cinemabook.booking;

import org.springframework.stereotype.Service;
import java.io.*;
import java.time.LocalDate;
import java.util.*;

@Service
public class BookingService {

    private static final String CSV_PATH = System.getProperty("user.dir") + "/src/main/resources/data/bookings.csv";
    private static final String HEADER = "bookingId,userId,showId,movieTitle,showDate,showTime,hall,seats,totalAmount,status,bookingDate";

    public List<Booking> getAllBookings() {
        List<Booking> bookings = new ArrayList<>();
        File file = new File(CSV_PATH);
        if (!file.exists()) return bookings;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first) { first = false; continue; }
                if (line.trim().isEmpty()) continue;
                String[] p = line.split(",", -1);
                if (p.length == 11) {
                    bookings.add(new Booking(
                        p[0].trim(), p[1].trim(), p[2].trim(), p[3].trim(),
                        p[4].trim(), p[5].trim(), p[6].trim(),
                        Integer.parseInt(p[7].trim()),
                        p[8].trim(), p[9].trim(), p[10].trim()
                    ));
                }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return bookings;
    }

    public List<Booking> getBookingsByUserId(String userId) {
        return getAllBookings().stream()
                .filter(b -> b.getUserId().equals(userId))
                .toList();
    }

    public Optional<Booking> getBookingById(String bookingId) {
        return getAllBookings().stream()
                .filter(b -> b.getBookingId().equals(bookingId))
                .findFirst();
    }

    public long countByStatus(String status) {
        return getAllBookings().stream()
                .filter(b -> b.getStatus().equalsIgnoreCase(status))
                .count();
    }

    public Booking saveBooking(String userId, String showId, String movieTitle,
                               String showDate, String showTime, String hall,
                               int seats, String price) {
        double total = seats * Double.parseDouble(price);
        Booking b = new Booking(
            "BKG" + System.currentTimeMillis(),
            userId, showId, movieTitle,
            showDate, showTime, hall,
            seats,
            String.format("%.2f", total),
            "CONFIRMED",
            LocalDate.now().toString()
        );
        File file = new File(CSV_PATH);
        file.getParentFile().mkdirs();
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, true))) {
            if (file.length() == 0) bw.write(HEADER + "\n");
            bw.write(toCsvLine(b) + "\n");
        } catch (IOException e) { e.printStackTrace(); }
        return b;
    }

    public void cancelBooking(String bookingId) {
        List<Booking> bookings = getAllBookings();
        for (Booking b : bookings) {
            if (b.getBookingId().equals(bookingId)) {
                b.setStatus("CANCELLED");
                break;
            }
        }
        writeAll(bookings);
    }

    public void deleteBooking(String bookingId) {
        List<Booking> bookings = getAllBookings();
        bookings.removeIf(b -> b.getBookingId().equals(bookingId));
        writeAll(bookings);
    }

    private void writeAll(List<Booking> bookings) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(CSV_PATH, false))) {
            bw.write(HEADER + "\n");
            for (Booking b : bookings) bw.write(toCsvLine(b) + "\n");
        } catch (IOException e) { e.printStackTrace(); }
    }

    private String toCsvLine(Booking b) {
        return String.join(",",
                b.getBookingId(), b.getUserId(), b.getShowId(),
                b.getMovieTitle(), b.getShowDate(), b.getShowTime(),
                b.getHall(), String.valueOf(b.getSeats()),
                b.getTotalAmount(), b.getStatus(), b.getBookingDate());
    }
}
