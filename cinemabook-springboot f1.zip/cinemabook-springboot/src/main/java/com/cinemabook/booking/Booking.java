package com.cinemabook.booking;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Booking {
    private String bookingId;
    private String userId;
    private String showId;
    private String movieTitle;
    private String showDate;
    private String showTime;
    private String hall;
    private int seats;
    private String totalAmount;
    private String status;     // CONFIRMED, CANCELLED
    private String bookingDate;
}
